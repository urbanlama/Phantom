#ifndef OBFUSCATED_STRING_H
#define OBFUSCATED_STRING_H

// Diese Datei dient dazu, die Referenz aus logger.cpp aufzulösen.
// Die eigentliche Implementierung befindet sich aus Gründen der Einfachheit
// und der Compile-Zeit-Verfügbarkeit direkt in config.h.

#include "config.h"

#endif // OBFUSCATED_STRING_H 