#ifndef EARLY_BIRD_INJECTION_H
#define EARLY_BIRD_INJECTION_H

#include "I_InjectionTechnique.h"
#include "InjectionResult.h"
#include "SyscallData.h"
#include <windows.h>
#include <winternl.h>

class EarlyBirdInjection : public I_InjectionTechnique {
public:
    EarlyBirdInjection(HMODULE hNtdll);
    ~EarlyBirdInjection() = default;

    InjectionResult inject(
        const std::string& processName, 
        const std::vector<unsigned char>& payloadBundle,
        size_t codeOffset
    ) override;

    const char* getName() const override { return "Early Bird Injection (SetThreadContext)"; }

private:
    bool resolveSyscalls();
    HMODULE hNtdll;
};

#endif // EARLY_BIRD_INJECTION_H 